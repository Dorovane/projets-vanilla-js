# Outil pour calculer la TVA selon plusieurs taux et déterminer la marge brute d’un produit, exportable en PDF
